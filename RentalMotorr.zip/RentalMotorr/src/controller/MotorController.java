package controller;

import connection.Connector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

public class MotorController {

    public void tampilData(DefaultTableModel model) {

        try {

            model.setRowCount(0);

            Connection conn = Connector.getConnection();

            Statement st = conn.createStatement();

            String sql = "SELECT * FROM motor";

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                Object[] data = {
                    rs.getString("id_motor"),
                    rs.getString("merk"),
                    rs.getString("tipe"),
                    rs.getString("plat_nomor"),
                    rs.getString("harga_sewa"),
                    rs.getString("status_motor")
                };

                model.addRow(data);
            }

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }

    public void simpanData(String merk, String tipe, String plat, String harga) {

        try {

            Connection conn = Connector.getConnection();

            String sql = "INSERT INTO motor VALUES (null,?,?,?,?,?)";

            PreparedStatement pst = conn.prepareStatement(sql);

            pst.setString(1, merk);
            pst.setString(2, tipe);
            pst.setString(3, plat);
            pst.setString(4, harga);
            pst.setString(5, "Tersedia");

            pst.execute();

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }

    public void hapusData(String id) {

        try {

            Connection conn = Connector.getConnection();

            String sql = "DELETE FROM motor WHERE id_motor=?";

            PreparedStatement pst = conn.prepareStatement(sql);

            pst.setString(1, id);

            pst.execute();

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }
}
