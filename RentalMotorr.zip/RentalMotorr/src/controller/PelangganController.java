package controller;

import connection.Connector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

public class PelangganController {

    public void tampilData(DefaultTableModel model) {

        try {

            model.setRowCount(0);

            Connection conn = Connector.getConnection();

            Statement st = conn.createStatement();

            String sql = "SELECT * FROM pelanggan";

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                Object[] data = {
                    rs.getString("id_pelanggan"),
                    rs.getString("nama"),
                    rs.getString("alamat"),
                    rs.getString("no_hp"),
                    rs.getString("no_ktp")
                };

                model.addRow(data);
            }

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }

    public void simpanData(String nama, String alamat, String hp, String ktp) {

        try {

            Connection conn = Connector.getConnection();

            String sql = "INSERT INTO pelanggan VALUES (null,?,?,?,?)";

            PreparedStatement pst = conn.prepareStatement(sql);

            pst.setString(1, nama);
            pst.setString(2, alamat);
            pst.setString(3, hp);
            pst.setString(4, ktp);

            pst.execute();

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }

    public void hapusData(String id) {

        try {

            Connection conn = Connector.getConnection();

            String sql = "DELETE FROM pelanggan WHERE id_pelanggan=?";

            PreparedStatement pst = conn.prepareStatement(sql);

            pst.setString(1, id);

            pst.execute();

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }
}
