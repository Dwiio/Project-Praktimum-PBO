package controller;

import connection.Connector;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class PengembalianController {

    public void prosesKembali(String idRental, String idMotor) {

        try {

            Connection conn = Connector.getConnection();

            String sql = "UPDATE rental "
                    + "SET status_rental='Selesai' "
                    + "WHERE id_rental='"
                    + idRental
                    + "'";

            PreparedStatement pst = conn.prepareStatement(sql);

            pst.execute();

            String sql2 = "UPDATE motor "
                    + "SET status_motor='Tersedia' "
                    + "WHERE id_motor='"
                    + idMotor
                    + "'";

            PreparedStatement pst2 = conn.prepareStatement(sql2);

            pst2.execute();

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }
}
