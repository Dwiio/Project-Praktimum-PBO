package controller;

import connection.Connector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

public class RentalController {

    Connection conn = Connector.getConnection();

    // SIMPAN RENTAL
    public void simpanRental(
            String idPelanggan,
            String idMotor,
            String tanggalSewa,
            String tanggalKembali,
            int totalHarga
    ) {

        try {

            String sql = "INSERT INTO rental "
                    + "(id_pelanggan, id_motor, tanggal_sewa, tanggal_kembali, total_harga, status_rental) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, idPelanggan);
            ps.setString(2, idMotor);
            ps.setString(3, tanggalSewa);
            ps.setString(4, tanggalKembali);
            ps.setInt(5, totalHarga);
            ps.setString(6, "Disewa");

            ps.executeUpdate();

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }

    // TAMPIL DATA RENTAL
    public void tampilData(DefaultTableModel model) {

        try {

            String sql = "SELECT * FROM rental";

            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                Object[] data = {

                    rs.getInt("id_rental"),
                    rs.getInt("id_pelanggan"),
                    rs.getInt("id_motor"),
                    rs.getDate("tanggal_sewa"),
                    rs.getDate("tanggal_kembali"),
                    rs.getInt("total_harga"),
                    rs.getString("status_rental")
                };

                model.addRow(data);
            }

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }

    // AMBIL HARGA MOTOR
    public int getHargaMotor(String idMotor) {

        int harga = 0;

        try {

            String sql = "SELECT harga_sewa FROM motor WHERE id_motor = ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, idMotor);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                harga = rs.getInt("harga_sewa");
            }

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

        return harga;
    }

    // HAPUS RENTAL
    public void hapusRental(int idRental) {

        try {

            String sql = "DELETE FROM rental WHERE id_rental = ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, idRental);

            ps.executeUpdate();

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }
}