package view;

import controller.MotorController;
import java.awt.Font;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ViewMotor extends JFrame {

    JTable table;

    JScrollPane scroll;

    JButton btnTambah = new JButton("Tambah Motor");
    JButton btnHapus = new JButton("Hapus");
    JButton btnPelanggan = new JButton("Data Pelanggan");
    JButton btnRental = new JButton("Rental");
    JButton btnKembali = new JButton("Pengembalian");

    DefaultTableModel model;

    MotorController controller = new MotorController();

    public ViewMotor() {

        setTitle("DATA MOTOR");
        setSize(900, 450);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        btnTambah.setBounds(20, 20, 140, 35);
        btnHapus.setBounds(170, 20, 120, 35);
        btnPelanggan.setBounds(300, 20, 150, 35);
        btnRental.setBounds(460, 20, 120, 35);
        btnKembali.setBounds(590, 20, 150, 35);

        add(btnTambah);
        add(btnHapus);
        add(btnPelanggan);
        add(btnRental);
        add(btnKembali);

        String[] judul = {
            "ID",
            "Merk",
            "Tipe",
            "Plat",
            "Harga",
            "Status"
        };

        model = new DefaultTableModel(judul, 0);

        table = new JTable(model);

        scroll = new JScrollPane(table);

        scroll.setBounds(20, 80, 840, 280);

        add(scroll);

        controller.tampilData(model);

        btnTambah.addActionListener(e -> {

            dispose();
            new InputMotor();
        });

        btnPelanggan.addActionListener(e -> {

            dispose();
            new ViewPelanggan();
        });

        btnRental.addActionListener(e -> {

            dispose();
            new ViewRental();
        });

        btnKembali.addActionListener(e -> {

            dispose();
            new ViewPengembalian();
        });

        btnHapus.addActionListener(e -> {

            try {

                int baris = table.getSelectedRow();

                String id = table.getValueAt(baris, 0).toString();

                controller.hapusData(id);

                JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");

                controller.tampilData(model);

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(null, "Pilih Data Dulu");
            }
        });
    }
}
