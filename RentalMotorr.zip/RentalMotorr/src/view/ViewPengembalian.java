package view;

import controller.PengembalianController;
import java.awt.Font;
import javax.swing.*;

public class ViewPengembalian extends JFrame {

    JLabel title = new JLabel("PENGEMBALIAN MOTOR");

    JLabel lRental = new JLabel("ID Rental");
    JLabel lMotor = new JLabel("ID Motor");

    JTextField txtRental = new JTextField();
    JTextField txtMotor = new JTextField();

    JButton btnKembalikan = new JButton("Kembalikan");

    PengembalianController controller = new PengembalianController();

    public ViewPengembalian() {

        setTitle("Pengembalian");
        setSize(400, 300);
        setLayout(null);
        setLocationRelativeTo(null);
        setVisible(true);

        title.setBounds(60, 10, 300, 40);
        title.setFont(new Font("Arial", Font.BOLD, 20));

        lRental.setBounds(30, 80, 100, 30);
        txtRental.setBounds(150, 80, 180, 30);

        lMotor.setBounds(30, 130, 100, 30);
        txtMotor.setBounds(150, 130, 180, 30);

        btnKembalikan.setBounds(120, 200, 140, 35);

        add(title);

        add(lRental);
        add(txtRental);

        add(lMotor);
        add(txtMotor);

        add(btnKembalikan);

        btnKembalikan.addActionListener(e -> {

            controller.prosesKembali(
                    txtRental.getText(),
                    txtMotor.getText()
            );

            JOptionPane.showMessageDialog(null, "Motor Berhasil Dikembalikan");

            dispose();

            new ViewMotor();
        });
    }
}
