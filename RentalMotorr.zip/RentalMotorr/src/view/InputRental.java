package view;

import controller.RentalController;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.*;
import javax.swing.text.MaskFormatter;

public class InputRental extends JFrame {

    JLabel title = new JLabel("INPUT RENTAL");

    JLabel lPelanggan = new JLabel("ID Pelanggan");
    JLabel lMotor = new JLabel("ID Motor");
    JLabel lTanggal = new JLabel("Tanggal Sewa");
    JLabel lKembali = new JLabel("Tanggal Kembali");
    JLabel lHarga = new JLabel("Total Harga");
    JLabel lLama = new JLabel("Lama Hari");

    JTextField txtPelanggan = new JTextField();
    JTextField txtMotor = new JTextField();

    // FORMAT TANGGAL MYSQL
    JFormattedTextField txtTanggal =
            new JFormattedTextField(
                    createFormatter("####-##-##")
            );

    JFormattedTextField txtKembali =
            new JFormattedTextField(
                    createFormatter("####-##-##")
            );

    JTextField txtHarga = new JTextField();
    JTextField txtLama = new JTextField();

    JButton btnSimpan = new JButton("Simpan");
    JButton btnMenu = new JButton("Kembali");

    RentalController controller =
            new RentalController();

    public InputRental() {

        setTitle("Rental Motor");
        setSize(430, 470);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        title.setBounds(100, 10, 300, 40);
        title.setFont(new Font("Arial", Font.BOLD, 20));

        lPelanggan.setBounds(30, 70, 120, 30);
        txtPelanggan.setBounds(170, 70, 180, 30);

        lMotor.setBounds(30, 110, 120, 30);
        txtMotor.setBounds(170, 110, 180, 30);

        lTanggal.setBounds(30, 150, 120, 30);
        txtTanggal.setBounds(170, 150, 180, 30);

        lKembali.setBounds(30, 190, 120, 30);
        txtKembali.setBounds(170, 190, 180, 30);

        lLama.setBounds(30, 230, 120, 30);
        txtLama.setBounds(170, 230, 180, 30);

        lHarga.setBounds(30, 270, 120, 30);
        txtHarga.setBounds(170, 270, 180, 30);

        txtHarga.setEditable(false);

        btnSimpan.setBounds(90, 340, 120, 35);
        btnMenu.setBounds(230, 340, 120, 35);

        add(title);

        add(lPelanggan);
        add(txtPelanggan);

        add(lMotor);
        add(txtMotor);

        add(lTanggal);
        add(txtTanggal);

        add(lKembali);
        add(txtKembali);

        add(lLama);
        add(txtLama);

        add(lHarga);
        add(txtHarga);

        add(btnSimpan);
        add(btnMenu);

        // HITUNG HARGA
        txtLama.addKeyListener(new KeyAdapter() {

            @Override
            public void keyReleased(KeyEvent e) {

                try {

                    String idMotor =
                            txtMotor.getText();

                    int lama =
                            Integer.parseInt(
                                    txtLama.getText()
                            );

                    int hargaMotor =
                            controller.getHargaMotor(idMotor);

                    int totalHarga =
                            hargaMotor * lama;

                    txtHarga.setText(
                            String.valueOf(totalHarga)
                    );

                } catch (Exception ex) {

                    txtHarga.setText("0");
                }
            }
        });

        // SIMPAN RENTAL
        btnSimpan.addActionListener(e -> {

            try {

                int totalHarga =
                        Integer.parseInt(
                                txtHarga.getText()
                        );

                controller.simpanRental(
                        txtPelanggan.getText(),
                        txtMotor.getText(),
                        txtTanggal.getText(),
                        txtKembali.getText(),
                        totalHarga
                );

                JOptionPane.showMessageDialog(
                        null,
                        "Rental Berhasil Ditambahkan"
                );

                dispose();

                new ViewRental();

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        null,
                        ex.getMessage()
                );
            }
        });

        btnMenu.addActionListener(e -> {

            dispose();

            new ViewMotor();
        });

        setVisible(true);
    }

    // FORMATTER
    private MaskFormatter createFormatter(String s) {

        MaskFormatter formatter = null;

        try {

            formatter = new MaskFormatter(s);

            formatter.setPlaceholderCharacter('_');

        } catch (java.text.ParseException ex) {

            ex.printStackTrace();
        }

        return formatter;
    }
}