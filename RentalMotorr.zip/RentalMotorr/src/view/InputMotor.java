package view;

import controller.MotorController;
import java.awt.Font;
import javax.swing.*;

public class InputMotor extends JFrame {

    JLabel title = new JLabel("INPUT MOTOR");

    JLabel lMerk = new JLabel("Merk");
    JLabel lTipe = new JLabel("Tipe");
    JLabel lPlat = new JLabel("Plat Nomor");
    JLabel lHarga = new JLabel("Harga Sewa");

    JTextField txtMerk = new JTextField();
    JTextField txtTipe = new JTextField();
    JTextField txtPlat = new JTextField();
    JTextField txtHarga = new JTextField();

    JButton btnSimpan = new JButton("Simpan");
    JButton btnKembali = new JButton("Kembali");

    MotorController controller = new MotorController();

    public InputMotor() {

        setTitle("Input Motor");
        setSize(420, 350);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        title.setBounds(110, 10, 300, 40);
        title.setFont(new Font("Arial", Font.BOLD, 20));

        lMerk.setBounds(30, 70, 100, 30);
        txtMerk.setBounds(150, 70, 180, 30);

        lTipe.setBounds(30, 110, 100, 30);
        txtTipe.setBounds(150, 110, 180, 30);

        lPlat.setBounds(30, 150, 100, 30);
        txtPlat.setBounds(150, 150, 180, 30);

        lHarga.setBounds(30, 190, 100, 30);
        txtHarga.setBounds(150, 190, 180, 30);

        btnSimpan.setBounds(90, 250, 100, 35);
        btnKembali.setBounds(210, 250, 100, 35);

        add(title);

        add(lMerk);
        add(txtMerk);

        add(lTipe);
        add(txtTipe);

        add(lPlat);
        add(txtPlat);

        add(lHarga);
        add(txtHarga);

        add(btnSimpan);
        add(btnKembali);

        btnSimpan.addActionListener(e -> {

            controller.simpanData(
                    txtMerk.getText(),
                    txtTipe.getText(),
                    txtPlat.getText(),
                    txtHarga.getText()
            );

            JOptionPane.showMessageDialog(null, "Motor Berhasil Ditambahkan");

            dispose();

            new ViewMotor();
        });

        btnKembali.addActionListener(e -> {

            dispose();

            new ViewMotor();
        });
    }
}
