package view;

import controller.RentalController;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ViewRental extends JFrame {

    JTable table;

    JScrollPane scroll;

    JButton btnTambah = new JButton("Tambah Rental");
    JButton btnKembali = new JButton("Menu");

    DefaultTableModel model;

    RentalController controller = new RentalController();

    public ViewRental() {

        setTitle("DATA RENTAL");
        setSize(900, 450);
        setLayout(null);
        setLocationRelativeTo(null);
        setVisible(true);

        btnTambah.setBounds(20, 20, 160, 35);
        btnKembali.setBounds(200, 20, 120, 35);

        add(btnTambah);
        add(btnKembali);

        String[] judul = {
            "ID",
            "ID Pelanggan",
            "ID Motor",
            "Tanggal Sewa",
            "Tanggal Kembali",
            "Total",
            "Status"
        };

        model = new DefaultTableModel(judul, 0);

        table = new JTable(model);

        scroll = new JScrollPane(table);

        scroll.setBounds(20, 80, 840, 260);

        add(scroll);

        controller.tampilData(model);

        btnTambah.addActionListener(e -> {

            dispose();
            new InputRental();
        });

        btnKembali.addActionListener(e -> {

            dispose();
            new ViewMotor();
        });
    }
}
