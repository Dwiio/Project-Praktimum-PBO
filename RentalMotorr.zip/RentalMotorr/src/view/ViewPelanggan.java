package view;

import controller.PelangganController;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ViewPelanggan extends JFrame {

    JTable table;

    JScrollPane scroll;

    JButton btnTambah = new JButton("Tambah Pelanggan");
    JButton btnHapus = new JButton("Hapus");
    JButton btnKembali = new JButton("Kembali");

    DefaultTableModel model;

    PelangganController controller = new PelangganController();

    public ViewPelanggan() {

        setTitle("DATA PELANGGAN");
        setSize(800, 420);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        btnTambah.setBounds(20, 20, 170, 35);
        btnHapus.setBounds(210, 20, 120, 35);
        btnKembali.setBounds(350, 20, 120, 35);

        add(btnTambah);
        add(btnHapus);
        add(btnKembali);

        String[] judul = {
            "ID",
            "Nama",
            "Alamat",
            "No HP",
            "No KTP"
        };

        model = new DefaultTableModel(judul, 0);

        table = new JTable(model);

        scroll = new JScrollPane(table);

        scroll.setBounds(20, 80, 740, 250);

        add(scroll);

        controller.tampilData(model);

        btnTambah.addActionListener(e -> {

            dispose();

            new InputPelanggan();
        });

        btnKembali.addActionListener(e -> {

            dispose();

            new ViewMotor();
        });

        btnHapus.addActionListener(e -> {

            try {

                int baris = table.getSelectedRow();

                String id = table.getValueAt(baris, 0).toString();

                controller.hapusData(id);

                JOptionPane.showMessageDialog(null, "Data Pelanggan Berhasil Dihapus");

                controller.tampilData(model);

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(null, "Pilih Data Yang Ingin Dihapus");
            }
        });
    }
}
