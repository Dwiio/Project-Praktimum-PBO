
package model;

public class Motor {

    int id_motor;
    String merk;
    String tipe;
    String plat_nomor;
    int harga_sewa;
    String status_motor;

    public Motor() {

    }

    public Motor(
            int id_motor,
            String merk,
            String tipe,
            String plat_nomor,
            int harga_sewa,
            String status_motor
    ) {

        this.id_motor = id_motor;
        this.merk = merk;
        this.tipe = tipe;
        this.plat_nomor = plat_nomor;
        this.harga_sewa = harga_sewa;
        this.status_motor = status_motor;
    }
}