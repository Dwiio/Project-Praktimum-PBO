package model;

public class Motor extends BaseModel {

    private String merk;
    private String tipe;
    private String plat_nomor;
    private int harga_sewa;
    private String status_motor;

    public Motor() {
    }

    public Motor(int id_motor, String merk, String tipe, String plat_nomor,
                 int harga_sewa, String status_motor) {
        super(id_motor);
        this.merk = merk;
        this.tipe = tipe;
        this.plat_nomor = plat_nomor;
        this.harga_sewa = harga_sewa;
        this.status_motor = status_motor;
    }

    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public String getTipe() {
        return tipe;
    }

    public void setTipe(String tipe) {
        this.tipe = tipe;
    }

    public String getPlat_nomor() {
        return plat_nomor;
    }

    public void setPlat_nomor(String plat_nomor) {
        this.plat_nomor = plat_nomor;
    }

    public int getHarga_sewa() {
        return harga_sewa;
    }

    public void setHarga_sewa(int harga_sewa) {
        this.harga_sewa = harga_sewa;
    }

    public String getStatus_motor() {
        return status_motor;
    }

    public void setStatus_motor(String status_motor) {
        this.status_motor = status_motor;
    }

    @Override
    public String getInfo() {
        return merk + " " + tipe + " - " + plat_nomor;
    }
}