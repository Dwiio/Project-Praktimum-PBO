
package model;

public class Pengembalian {

    int id_pengembalian;
    int id_rental;
    int id_motor;

    String tanggal_dikembalikan;
}