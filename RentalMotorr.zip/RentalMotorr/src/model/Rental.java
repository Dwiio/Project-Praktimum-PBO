package model;

public class Rental extends BaseModel {

    private int id_pelanggan;
    private int id_motor;
    private String tanggal_sewa;
    private String tanggal_kembali;
    private int total_harga;
    private String status_rental;

    public Rental() {
    }

    public Rental(int id_rental, int id_pelanggan, int id_motor,
                  String tanggal_sewa, String tanggal_kembali,
                  int total_harga, String status_rental) {
        super(id_rental);
        this.id_pelanggan = id_pelanggan;
        this.id_motor = id_motor;
        this.tanggal_sewa = tanggal_sewa;
        this.tanggal_kembali = tanggal_kembali;
        this.total_harga = total_harga;
        this.status_rental = status_rental;
    }

    public int getId_pelanggan() {
        return id_pelanggan;
    }

    public void setId_pelanggan(int id_pelanggan) {
        this.id_pelanggan = id_pelanggan;
    }

    public int getId_motor() {
        return id_motor;
    }

    public void setId_motor(int id_motor) {
        this.id_motor = id_motor;
    }

    public String getTanggal_sewa() {
        return tanggal_sewa;
    }

    public void setTanggal_sewa(String tanggal_sewa) {
        this.tanggal_sewa = tanggal_sewa;
    }

    public String getTanggal_kembali() {
        return tanggal_kembali;
    }

    public void setTanggal_kembali(String tanggal_kembali) {
        this.tanggal_kembali = tanggal_kembali;
    }

    public int getTotal_harga() {
        return total_harga;
    }

    public void setTotal_harga(int total_harga) {
        this.total_harga = total_harga;
    }

    public String getStatus_rental() {
        return status_rental;
    }

    public void setStatus_rental(String status_rental) {
        this.status_rental = status_rental;
    }

    @Override
    public String getInfo() {
        return "Rental ID " + id + " | Total: " + total_harga;
    }
}