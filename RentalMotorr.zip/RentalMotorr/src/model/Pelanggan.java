
package model;

public class Pelanggan {

    int id_pelanggan;
    String nama;
    String alamat;
    String no_hp;
    String no_ktp;
}