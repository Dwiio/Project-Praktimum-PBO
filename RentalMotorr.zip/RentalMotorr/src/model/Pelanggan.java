package model;

public class Pelanggan extends BaseModel {

    private String nama;
    private String alamat;
    private String no_hp;
    private String no_ktp;

    public Pelanggan() {
    }

    public Pelanggan(int id_pelanggan, String nama, String alamat,
                     String no_hp, String no_ktp) {
        super(id_pelanggan);
        this.nama = nama;
        this.alamat = alamat;
        this.no_hp = no_hp;
        this.no_ktp = no_ktp;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getNo_hp() {
        return no_hp;
    }

    public void setNo_hp(String no_hp) {
        this.no_hp = no_hp;
    }

    public String getNo_ktp() {
        return no_ktp;
    }

    public void setNo_ktp(String no_ktp) {
        this.no_ktp = no_ktp;
    }

    @Override
    public String getInfo() {
        return nama + " - " + no_hp;
    }
}