package model;

public abstract class BaseModel {

    protected int id;

    public BaseModel() {
    }

    public BaseModel(int id) {
        this.id = id;
    }

    // ENKAPSULASI
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    // ABSTRAKSI + POLYMORPHISM
    public abstract String getInfo();
}