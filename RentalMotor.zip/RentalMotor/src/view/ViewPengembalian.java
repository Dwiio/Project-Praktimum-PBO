
package view;

import view.ViewMotor;
import model.Connector;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.*;

public class ViewPengembalian extends JFrame {

    JLabel title = new JLabel("PENGEMBALIAN MOTOR");

    JLabel lRental = new JLabel("ID Rental");
    JLabel lMotor = new JLabel("ID Motor");

    JTextField txtRental = new JTextField();
    JTextField txtMotor = new JTextField();

    JButton btnKembalikan = new JButton("Kembalikan");

    public ViewPengembalian() {

        setTitle("Pengembalian");
        setSize(400, 300);
        setLayout(null);
        setLocationRelativeTo(null);
        setVisible(true);

        title.setBounds(60, 10, 300, 40);
        title.setFont(new Font("Arial", Font.BOLD, 20));

        lRental.setBounds(30, 80, 100, 30);
        txtRental.setBounds(150, 80, 180, 30);

        lMotor.setBounds(30, 130, 100, 30);
        txtMotor.setBounds(150, 130, 180, 30);

        btnKembalikan.setBounds(120, 200, 140, 35);

        add(title);

        add(lRental);
        add(txtRental);

        add(lMotor);
        add(txtMotor);

        add(btnKembalikan);

        btnKembalikan.addActionListener(e -> prosesKembali());
    }

    void prosesKembali() {

        try {

            Connection conn = Connector.getConnection();

            String sql = "UPDATE rental "
                    + "SET status_rental='Selesai' "
                    + "WHERE id_rental='"
                    + txtRental.getText()
                    + "'";

            PreparedStatement pst = conn.prepareStatement(sql);

            pst.execute();

            String sql2 = "UPDATE motor "
                    + "SET status_motor='Tersedia' "
                    + "WHERE id_motor='"
                    + txtMotor.getText()
                    + "'";

            PreparedStatement pst2 = conn.prepareStatement(sql2);

            pst2.execute();

            JOptionPane.showMessageDialog(null, "Motor Berhasil Dikembalikan");

            dispose();

            new ViewMotor();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}