package view;

import view.ViewMotor;
import view.InputPelanggan;
import model.Connector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ViewPelanggan extends JFrame {

    JTable table;

    JScrollPane scroll;

    JButton btnTambah = new JButton("Tambah Pelanggan");
    JButton btnHapus = new JButton("Hapus");
    JButton btnKembali = new JButton("Kembali");

    DefaultTableModel model;

    public ViewPelanggan() {

        setTitle("DATA PELANGGAN");
        setSize(800, 420);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        btnTambah.setBounds(20, 20, 170, 35);
        btnHapus.setBounds(210, 20, 120, 35);
        btnKembali.setBounds(350, 20, 120, 35);

        add(btnTambah);
        add(btnHapus);
        add(btnKembali);

        String[] judul = {
            "ID",
            "Nama",
            "Alamat",
            "No HP",
            "No KTP"
        };

        model = new DefaultTableModel(judul, 0);

        table = new JTable(model);

        scroll = new JScrollPane(table);

        scroll.setBounds(20, 80, 740, 250);

        add(scroll);

        tampilData();

        btnTambah.addActionListener(e -> {

            dispose();

            new InputPelanggan();
        });

        btnKembali.addActionListener(e -> {

            dispose();

            new ViewMotor();
        });

        btnHapus.addActionListener(e -> hapusData());
    }

    void tampilData() {

        try {

            model.setRowCount(0);

            Connection conn = Connector.getConnection();

            Statement st = conn.createStatement();

            String sql = "SELECT * FROM pelanggan";

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                Object[] data = {

                    rs.getString("id_pelanggan"),
                    rs.getString("nama"),
                    rs.getString("alamat"),
                    rs.getString("no_hp"),
                    rs.getString("no_ktp")
                };

                model.addRow(data);
            }

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }

    void hapusData() {

        try {

            int baris = table.getSelectedRow();

            String id = table.getValueAt(baris, 0).toString();

            Connection conn = Connector.getConnection();

            String sql = "DELETE FROM pelanggan WHERE id_pelanggan=?";

            PreparedStatement pst = conn.prepareStatement(sql);

            pst.setString(1, id);

            pst.execute();

            JOptionPane.showMessageDialog(null, "Data Pelanggan Berhasil Dihapus");

            tampilData();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, "Pilih Data Yang Ingin Dihapus");
        }
    }
}