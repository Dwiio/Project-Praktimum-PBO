
package view;

import model.Connector;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.*;

public class InputPelanggan extends JFrame {

    JLabel title = new JLabel("INPUT PELANGGAN");

    JLabel lNama = new JLabel("Nama");
    JLabel lAlamat = new JLabel("Alamat");
    JLabel lHP = new JLabel("No HP");
    JLabel lKTP = new JLabel("No KTP");

    JTextField txtNama = new JTextField();
    JTextField txtAlamat = new JTextField();
    JTextField txtHP = new JTextField();
    JTextField txtKTP = new JTextField();

    JButton btnSimpan = new JButton("Simpan");

    public InputPelanggan() {

        setTitle("Input Pelanggan");
        setSize(400, 350);
        setLayout(null);
        setLocationRelativeTo(null);
        setVisible(true);

        title.setBounds(80, 10, 300, 40);
        title.setFont(new Font("Arial", Font.BOLD, 20));

        lNama.setBounds(30, 70, 100, 30);
        txtNama.setBounds(150, 70, 180, 30);

        lAlamat.setBounds(30, 110, 100, 30);
        txtAlamat.setBounds(150, 110, 180, 30);

        lHP.setBounds(30, 150, 100, 30);
        txtHP.setBounds(150, 150, 180, 30);

        lKTP.setBounds(30, 190, 100, 30);
        txtKTP.setBounds(150, 190, 180, 30);

        btnSimpan.setBounds(130, 250, 120, 35);

        add(title);

        add(lNama);
        add(txtNama);

        add(lAlamat);
        add(txtAlamat);

        add(lHP);
        add(txtHP);

        add(lKTP);
        add(txtKTP);

        add(btnSimpan);

        btnSimpan.addActionListener(e -> simpanData());
    }

    void simpanData() {

        try {

            Connection conn = Connector.getConnection();

            String sql = "INSERT INTO pelanggan VALUES (null,?,?,?,?)";

            PreparedStatement pst = conn.prepareStatement(sql);

            pst.setString(1, txtNama.getText());
            pst.setString(2, txtAlamat.getText());
            pst.setString(3, txtHP.getText());
            pst.setString(4, txtKTP.getText());

            pst.execute();

            JOptionPane.showMessageDialog(null, "Pelanggan Berhasil Ditambahkan");

            dispose();

            new ViewPelanggan();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}