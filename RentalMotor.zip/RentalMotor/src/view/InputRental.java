package view;

import model.Connector;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class InputRental extends JFrame {

    JLabel title = new JLabel("INPUT RENTAL");

    JLabel lPelanggan = new JLabel("ID Pelanggan");
    JLabel lMotor = new JLabel("ID Motor");
    JLabel lTanggal = new JLabel("Tanggal Sewa");
    JLabel lKembali = new JLabel("Tanggal Kembali");
    JLabel lHarga = new JLabel("Harga");
    JLabel lLama = new JLabel("Lama Hari");

    JTextField txtPelanggan = new JTextField();
    JTextField txtMotor = new JTextField();
    JTextField txtTanggal = new JTextField();
    JTextField txtKembali = new JTextField();
    JTextField txtHarga = new JTextField();
    JTextField txtLama = new JTextField();

    JButton btnSimpan = new JButton("Simpan");
    JButton btnMenu = new JButton("Kembali");

    public InputRental() {

        setTitle("Rental Motor");
        setSize(430, 450);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        title.setBounds(110, 10, 300, 40);
        title.setFont(new Font("Arial", Font.BOLD, 20));

        lPelanggan.setBounds(30, 70, 120, 30);
        txtPelanggan.setBounds(170, 70, 180, 30);

        lMotor.setBounds(30, 110, 120, 30);
        txtMotor.setBounds(170, 110, 180, 30);

        lTanggal.setBounds(30, 150, 120, 30);
        txtTanggal.setBounds(170, 150, 180, 30);

        lKembali.setBounds(30, 190, 120, 30);
        txtKembali.setBounds(170, 190, 180, 30);

        lHarga.setBounds(30, 230, 120, 30);
        txtHarga.setBounds(170, 230, 180, 30);

        lLama.setBounds(30, 270, 120, 30);
        txtLama.setBounds(170, 270, 180, 30);

        btnSimpan.setBounds(90, 340, 120, 35);
        btnMenu.setBounds(230, 340, 120, 35);

        add(title);

        add(lPelanggan);
        add(txtPelanggan);

        add(lMotor);
        add(txtMotor);

        add(lTanggal);
        add(txtTanggal);

        add(lKembali);
        add(txtKembali);

        add(lHarga);
        add(txtHarga);

        add(lLama);
        add(txtLama);

        add(btnSimpan);
        add(btnMenu);

        btnSimpan.addActionListener(e -> simpanRental());

        btnMenu.addActionListener(e -> {

            dispose();

            new ViewMotor();
        });
    }

    void simpanRental() {

        try {

            int harga = Integer.parseInt(txtHarga.getText());

            int lama = Integer.parseInt(txtLama.getText());

            int total = harga * lama;

            Connection conn = Connector.getConnection();

            String sql = "INSERT INTO rental VALUES "
                    + "(null,?,?,?,?,?,?)";

            PreparedStatement pst = conn.prepareStatement(sql);

            pst.setString(1, txtPelanggan.getText());
            pst.setString(2, txtMotor.getText());
            pst.setString(3, txtTanggal.getText());
            pst.setString(4, txtKembali.getText());
            pst.setInt(5, total);
            pst.setString(6, "Dipinjam");

            pst.execute();

            String update = "UPDATE motor "
                    + "SET status_motor='Disewa' "
                    + "WHERE id_motor='"
                    + txtMotor.getText()
                    + "'";

            PreparedStatement pst2 = conn.prepareStatement(update);

            pst2.execute();

            JOptionPane.showMessageDialog(null, "Rental Berhasil");

            dispose();

            new ViewRental();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}