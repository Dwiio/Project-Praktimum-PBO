package view;

import model.Connector;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class InputMotor extends JFrame {

    JLabel title = new JLabel("INPUT MOTOR");

    JLabel lMerk = new JLabel("Merk");
    JLabel lTipe = new JLabel("Tipe");
    JLabel lPlat = new JLabel("Plat Nomor");
    JLabel lHarga = new JLabel("Harga Sewa");

    JTextField txtMerk = new JTextField();
    JTextField txtTipe = new JTextField();
    JTextField txtPlat = new JTextField();
    JTextField txtHarga = new JTextField();

    JButton btnSimpan = new JButton("Simpan");
    JButton btnKembali = new JButton("Kembali");

    public InputMotor() {

        setTitle("Input Motor");
        setSize(420, 350);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        title.setBounds(110, 10, 300, 40);
        title.setFont(new Font("Arial", Font.BOLD, 20));

        lMerk.setBounds(30, 70, 100, 30);
        txtMerk.setBounds(150, 70, 180, 30);

        lTipe.setBounds(30, 110, 100, 30);
        txtTipe.setBounds(150, 110, 180, 30);

        lPlat.setBounds(30, 150, 100, 30);
        txtPlat.setBounds(150, 150, 180, 30);

        lHarga.setBounds(30, 190, 100, 30);
        txtHarga.setBounds(150, 190, 180, 30);

        btnSimpan.setBounds(90, 250, 100, 35);
        btnKembali.setBounds(210, 250, 100, 35);

        add(title);

        add(lMerk);
        add(txtMerk);

        add(lTipe);
        add(txtTipe);

        add(lPlat);
        add(txtPlat);

        add(lHarga);
        add(txtHarga);

        add(btnSimpan);
        add(btnKembali);

        btnSimpan.addActionListener(e -> simpanData());

        btnKembali.addActionListener(e -> {

            dispose();

            new ViewMotor();
        });
    }

    void simpanData() {

        try {

            Connection conn = Connector.getConnection();

            String sql = "INSERT INTO motor VALUES (null,?,?,?,?,?)";

            PreparedStatement pst = conn.prepareStatement(sql);

            pst.setString(1, txtMerk.getText());
            pst.setString(2, txtTipe.getText());
            pst.setString(3, txtPlat.getText());
            pst.setString(4, txtHarga.getText());
            pst.setString(5, "Tersedia");

            pst.execute();

            JOptionPane.showMessageDialog(null, "Motor Berhasil Ditambahkan");

            dispose();

            new ViewMotor();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}