package view;

import view.InputMotor;
import model.Connector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ViewMotor extends JFrame {

    JTable table;

    JScrollPane scroll;

    JButton btnTambah = new JButton("Tambah Motor");
    JButton btnHapus = new JButton("Hapus");
    JButton btnPelanggan = new JButton("Data Pelanggan");
    JButton btnRental = new JButton("Rental");
    JButton btnKembali = new JButton("Pengembalian");

    DefaultTableModel model;

    public ViewMotor() {

        setTitle("DATA MOTOR");
        setSize(900, 450);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        btnTambah.setBounds(20, 20, 140, 35);
        btnHapus.setBounds(170, 20, 120, 35);
        btnPelanggan.setBounds(300, 20, 150, 35);
        btnRental.setBounds(460, 20, 120, 35);
        btnKembali.setBounds(590, 20, 150, 35);

        add(btnTambah);
        add(btnHapus);
        add(btnPelanggan);
        add(btnRental);
        add(btnKembali);

        String[] judul = {
            "ID",
            "Merk",
            "Tipe",
            "Plat",
            "Harga",
            "Status"
        };

        model = new DefaultTableModel(judul, 0);

        table = new JTable(model);

        scroll = new JScrollPane(table);

        scroll.setBounds(20, 80, 840, 280);

        add(scroll);

        tampilData();

        btnTambah.addActionListener(e -> {

            dispose();
            new InputMotor();
        });

        btnPelanggan.addActionListener(e -> {

            dispose();
            new ViewPelanggan();
        });

        btnRental.addActionListener(e -> {

            dispose();
            new ViewRental();
        });

        btnKembali.addActionListener(e -> {

            dispose();
            new ViewPengembalian();
        });

        btnHapus.addActionListener(e -> hapusData());
    }

    void tampilData() {

        try {

            model.setRowCount(0);

            Connection conn = Connector.getConnection();

            Statement st = conn.createStatement();

            String sql = "SELECT * FROM motor";

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                Object[] data = {
                    rs.getString("id_motor"),
                    rs.getString("merk"),
                    rs.getString("tipe"),
                    rs.getString("plat_nomor"),
                    rs.getString("harga_sewa"),
                    rs.getString("status_motor")
                };

                model.addRow(data);
            }

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }

    void hapusData() {

        try {

            int baris = table.getSelectedRow();

            String id = table.getValueAt(baris, 0).toString();

            Connection conn = Connector.getConnection();

            String sql = "DELETE FROM motor WHERE id_motor=?";

            PreparedStatement pst = conn.prepareStatement(sql);

            pst.setString(1, id);

            pst.execute();

            JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");

            tampilData();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, "Pilih Data Dulu");
        }
    }
}