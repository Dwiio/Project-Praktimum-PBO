
package main;

import view.ViewMotor;

public class Main {

    public static void main(String[] args) {

        new ViewMotor();
    }
}