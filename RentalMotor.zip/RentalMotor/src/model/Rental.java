
package model;

public class Rental {

    int id_rental;
    int id_pelanggan;
    int id_motor;

    String tanggal_sewa;
    String tanggal_kembali;

    int total_harga;

    String status_rental;
}